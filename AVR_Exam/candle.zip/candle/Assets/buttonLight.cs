using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class buttonLight : MonoBehaviour
{
    bool is_on;
    public GameObject candle_flame;
    public Text BtnText;

    // Start is called before the first frame update
    void Start()
    {
        is_on = false;
        BtnText.text = "Turn On";
        candle_flame.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(1)){
            btnPress();
        }
    }

    public void btnPress(){
        is_on = !is_on;
        if(!is_on){
            // GameObject.Find("changeis_on").GetComponentInChildren<Text>().text = "Turn On";
            BtnText.text = "Turn On";
            candle_flame.SetActive(false);
            // candle_smoke.SetActive(false);
            // candle_light_src.SetActive(false);
            Debug.Log("Turned Off");
        }else{
            // GameObject.Find("changeis_on").GetComponentInChildren<Text>().text = "Turn Off";
            BtnText.text = "Turn Off";
            candle_flame.SetActive(true);
            // candle_smoke.SetActive(true);
            // candle_light_src.SetActive(true);
            Debug.Log("Turned On");
        }
    }
}
